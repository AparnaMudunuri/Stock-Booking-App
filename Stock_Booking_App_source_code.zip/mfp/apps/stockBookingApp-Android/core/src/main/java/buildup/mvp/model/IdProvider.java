package buildup.mvp.model;

public interface IdProvider {
    String identifier();
}
