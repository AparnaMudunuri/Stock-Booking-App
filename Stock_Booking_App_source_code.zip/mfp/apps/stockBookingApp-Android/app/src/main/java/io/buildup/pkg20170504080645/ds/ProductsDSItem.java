
package io.buildup.pkg20170504080645.ds;
import android.graphics.Bitmap;
import android.net.Uri;

import buildup.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class ProductsDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("name") public String name;
    @SerializedName("productavaialble") public String productavaialble;
    @SerializedName("category") public String category;
    @SerializedName("pricePerunitkglt") public String pricePerunitkglt;
    @SerializedName("rating") public String rating;
    @SerializedName("picture") public String picture;
    @SerializedName("quantity") public String quantity;
    @SerializedName("contact") public String contact;
    @SerializedName("id") public String id;
    @SerializedName("pictureUri") public transient Uri pictureUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(productavaialble);
        dest.writeString(category);
        dest.writeString(pricePerunitkglt);
        dest.writeString(rating);
        dest.writeString(picture);
        dest.writeString(quantity);
        dest.writeString(contact);
        dest.writeString(id);
    }

    public static final Creator<ProductsDSItem> CREATOR = new Creator<ProductsDSItem>() {
        @Override
        public ProductsDSItem createFromParcel(Parcel in) {
            ProductsDSItem item = new ProductsDSItem();

            item.name = in.readString();
            item.productavaialble = in.readString();
            item.category = in.readString();
            item.pricePerunitkglt = in.readString();
            item.rating = in.readString();
            item.picture = in.readString();
            item.quantity = in.readString();
            item.contact = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public ProductsDSItem[] newArray(int size) {
            return new ProductsDSItem[size];
        }
    };

}

