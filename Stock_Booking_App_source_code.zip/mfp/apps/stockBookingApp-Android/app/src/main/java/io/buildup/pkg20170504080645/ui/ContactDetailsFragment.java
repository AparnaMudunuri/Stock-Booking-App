package io.buildup.pkg20170504080645.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import buildup.behaviors.AnalyticsSearchBehavior;
import buildup.behaviors.FabBehaviour;
import buildup.behaviors.SelectionBehavior;
import buildup.ds.Datasource;
import buildup.ui.ListGridFragment;
import buildup.util.Constants;
import buildup.util.image.ImageLoader;
import buildup.util.image.PicassoImageLoader;
import buildup.util.ViewHolder;
import io.buildup.pkg20170504080645.ds.ContactScreen1DSService;
import io.buildup.pkg20170504080645.presenters.ContactDetailsPresenter;
import io.buildup.pkg20170504080645.R;
import java.util.List;
import static buildup.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import buildup.ds.SearchOptions;
import buildup.ds.filter.Filter;
import java.util.Arrays;
import io.buildup.pkg20170504080645.ds.ContactScreen1DSItem;
import io.buildup.pkg20170504080645.ds.ContactScreen1DS;
import buildup.mvp.view.CrudListView;
import buildup.ds.CrudDatasource;
import buildup.dialogs.DeleteItemDialog;
import android.support.v4.app.DialogFragment;
import android.content.Intent;
import buildup.util.Constants;
import static buildup.util.NavigationUtils.generateIntentToDetailOrForm;
import static buildup.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;

/**
 * "ContactDetailsFragment" listing
 */
public class ContactDetailsFragment extends ListGridFragment<ContactScreen1DSItem> implements CrudListView<ContactScreen1DSItem>, DeleteItemDialog.DeleteItemListener {

    private CrudDatasource<ContactScreen1DSItem> datasource;
    private List<ContactScreen1DSItem> selectedItemsForDelete;

    // "Add" button
    private FabBehaviour fabBehavior;

    public static ContactDetailsFragment newInstance(Bundle args) {
        ContactDetailsFragment fr = new ContactDetailsFragment();

        fr.setArguments(args);
        return fr;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addBehavior(pageViewBehavior("contactDetails"));
        setPresenter(new ContactDetailsPresenter(
            (CrudDatasource) getDatasource(),
            this
        ));
        addBehavior(new AnalyticsSearchBehavior(this, "ContactScreen1DS"));
        // Multiple selection
        SelectionBehavior<ContactScreen1DSItem> selectionBehavior = new SelectionBehavior<>(
            this,
            R.string.remove_items,
            R.drawable.ic_delete_alpha);

        selectionBehavior.setCallback(new SelectionBehavior.Callback<ContactScreen1DSItem>() {
            @Override
            public void onSelected(List<ContactScreen1DSItem> selectedItems) {
                selectedItemsForDelete = selectedItems;
                DialogFragment deleteDialog = new DeleteItemDialog(ContactDetailsFragment.this);
                deleteDialog.show(getActivity().getSupportFragmentManager(), "");
            }
        });
        addBehavior(selectionBehavior);

        // FAB button
        fabBehavior = new FabBehaviour(this, R.drawable.ic_add_white, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getPresenter().addForm();
            }
        });
        addBehavior(fabBehavior);
        
    }

    protected SearchOptions getSearchOptions() {
        SearchOptions.Builder searchOptionsBuilder = SearchOptions.Builder.searchOptions();
        return searchOptionsBuilder.build();
    }


    /**
    * Layout for the list itselft
    */
    @Override
    protected int getLayout() {
        return R.layout.fragment_list;
    }

    /**
    * Layout for each element in the list
    */
    @Override
    protected int getItemLayout() {
        return R.layout.contactdetails_item;
    }

    @Override
    protected Datasource<ContactScreen1DSItem> getDatasource() {
        if (datasource != null) {
            return datasource;
        }
        datasource = ContactScreen1DS.getInstance(getSearchOptions());
        return datasource;
    }

    @Override
    protected void bindView(ContactScreen1DSItem item, View view, int position) {
        
        ImageLoader imageLoader = new PicassoImageLoader(view.getContext());
        ImageView image = ViewHolder.get(view, R.id.image);
        imageLoader.load(imageLoaderRequest()
                        .withResourceToLoad(R.drawable.png_defaultmenuicon)
                        .withTargetView(image)
                        .fit()
                        .build()
        );
        
        
        
        TextView title = ViewHolder.get(view, R.id.title);
        
        title.setText((item.name != null ? item.name : ""));
        
    }

    @Override
    protected void itemClicked(final ContactScreen1DSItem item, final int position) {
        fabBehavior.hide(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                getPresenter().detail(item, position);
            }
        });
    }

    @Override
    public void showDetail(ContactScreen1DSItem item, int position) {
        Intent intent = generateIntentToDetailOrForm(item,
            position,
            getActivity(),
            ContactDetailsDetailActivity.class);

        if (!getResources().getBoolean(R.bool.tabletLayout)) {
            startActivityForResult(intent, Constants.DETAIL);
        } else {
            startActivity(intent);
        }
    }

    @Override
    public void showAdd() {
        startActivityForResult(
                generateIntentToDetailOrForm(null,
                        0,
                        getActivity(),
                        Contact2FormFormActivity.class
                ), Constants.MODE_CREATE
        );
    }

    @Override
    public void showEdit(ContactScreen1DSItem item, int position) {
        startActivityForResult(
                generateIntentToDetailOrForm(item,
                        position,
                        getActivity(),
                        Contact2FormFormActivity.class
                ), Constants.MODE_EDIT
        );
    }

    @Override
    public void deleteItem(boolean isDeleted) {
        if (isDeleted) {
            getPresenter().deleteItems(selectedItemsForDelete);
        }

        selectedItemsForDelete.clear();
    }

}
