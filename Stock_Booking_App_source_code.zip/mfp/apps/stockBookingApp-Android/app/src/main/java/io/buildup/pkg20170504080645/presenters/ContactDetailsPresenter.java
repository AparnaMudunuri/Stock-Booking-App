
package io.buildup.pkg20170504080645.presenters;

import io.buildup.pkg20170504080645.R;
import io.buildup.pkg20170504080645.ds.ContactScreen1DSItem;

import java.util.List;

import buildup.ds.CrudDatasource;
import buildup.ds.Datasource;
import buildup.mvp.presenter.BasePresenter;
import buildup.mvp.presenter.ListCrudPresenter;
import buildup.mvp.view.CrudListView;
import java.util.Map;
import java.util.HashMap;
import buildup.analytics.injector.AnalyticsReporterInjector;

public class ContactDetailsPresenter extends BasePresenter implements ListCrudPresenter<ContactScreen1DSItem>,
      Datasource.Listener<ContactScreen1DSItem>{

    private final CrudDatasource<ContactScreen1DSItem> crudDatasource;
    private final CrudListView<ContactScreen1DSItem> view;

    public ContactDetailsPresenter(CrudDatasource<ContactScreen1DSItem> crudDatasource,
                                         CrudListView<ContactScreen1DSItem> view) {
       this.crudDatasource = crudDatasource;
       this.view = view;
    }

    @Override
    public void deleteItem(ContactScreen1DSItem item) {
        crudDatasource.deleteItem(item, this);
    }

    @Override
    public void deleteItems(List<ContactScreen1DSItem> items) {
        crudDatasource.deleteItems(items, this);
    }

    @Override
    public void addForm() {
        view.showAdd();
    }

    @Override
    public void editForm(ContactScreen1DSItem item, int position) {
        view.showEdit(item, position);
    }

    @Override
    public void detail(ContactScreen1DSItem item, int position) {
        view.showDetail(item, position);
    }

    @Override
    public void onSuccess(ContactScreen1DSItem item) {
        logCrudAction("deleted", item.id);
        view.showMessage(R.string.items_deleted);
        view.refresh();
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic);
    }

    private void logCrudAction(String action, String id) {
      Map<String, String> paramsMap = new HashMap<>(3);
      //action will be one of created, updated or deleted
      paramsMap.put("action", action);
      paramsMap.put("entity", "ContactScreen1DSItem");
      paramsMap.put("identifier", id);

      AnalyticsReporterInjector.analyticsReporter().sendEvent(paramsMap);
    }
}
