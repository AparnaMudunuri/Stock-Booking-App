

package io.buildup.pkg20170504080645.ui;

import android.os.Bundle;

import io.buildup.pkg20170504080645.R;

import java.util.ArrayList;
import java.util.List;

import buildup.MenuItem;

import buildup.actions.StartActivityAction;
import buildup.util.Constants;
import static buildup.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;

/**
 * StockDetailsFragment menu fragment.
 */
public class StockDetailsFragment extends buildup.ui.MenuFragment {
    /**
     * Default constructor
     */
    public StockDetailsFragment(){
        super();
    }

    // Factory method
    public static StockDetailsFragment newInstance(Bundle args) {
        StockDetailsFragment fragment = new StockDetailsFragment();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addBehavior(pageViewBehavior("StockDetails"));
    }

    // Menu Fragment interface
    @Override
    public List<MenuItem> getMenuItems() {
        ArrayList<MenuItem> items = new ArrayList<MenuItem>();
        items.add(new MenuItem()
            .setLabel("Grains")
            .setIcon(R.drawable.png_1645)
            .setAction(new StartActivityAction(GrainsMenuItem1Activity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("Vegetables&fruits")
            .setIcon(R.drawable.jpg_images269)
            .setAction(new StartActivityAction(VegetablesfruitsActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("Oils")
            .setIcon(R.drawable.jpg_hairoilolivev270017807672)
            .setAction(new StartActivityAction(OilsMenuItem1Activity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("Dryfruits")
            .setIcon(R.drawable.jpg_dry334)
            .setAction(new StartActivityAction(DryfruitsMenuItem1Activity.class, Constants.DETAIL))
        );
        return items;
    }

    @Override
    public int getLayout() {
        return R.layout.fragment_grid;
    }

    @Override
    public int getItemLayout() {
        return R.layout.stockdetails_item;
    }
}
