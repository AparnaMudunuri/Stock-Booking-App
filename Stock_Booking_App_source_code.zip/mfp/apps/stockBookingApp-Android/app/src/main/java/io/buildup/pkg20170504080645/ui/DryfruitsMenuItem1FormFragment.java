
package io.buildup.pkg20170504080645.ui;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.view.View;
import buildup.ui.FormFragment;
import buildup.util.StringUtils;
import buildup.views.ImagePicker;
import buildup.views.TextWatcherAdapter;
import io.buildup.pkg20170504080645.ds.ProductsDSItem;
import io.buildup.pkg20170504080645.ds.ProductsDSService;
import io.buildup.pkg20170504080645.presenters.DryfruitsMenuItem1FormFormPresenter;
import io.buildup.pkg20170504080645.R;
import java.io.IOException;
import java.io.File;

import static android.net.Uri.fromFile;
import buildup.ds.Datasource;
import buildup.ds.CrudDatasource;
import buildup.ds.SearchOptions;
import buildup.ds.filter.Filter;
import java.util.Arrays;
import io.buildup.pkg20170504080645.ds.ProductsDSItem;
import io.buildup.pkg20170504080645.ds.ProductsDS;
import static buildup.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;

public class DryfruitsMenuItem1FormFragment extends FormFragment<ProductsDSItem> {

    private CrudDatasource<ProductsDSItem> datasource;
    public static DryfruitsMenuItem1FormFragment newInstance(Bundle args){
        DryfruitsMenuItem1FormFragment fr = new DryfruitsMenuItem1FormFragment();
        fr.setArguments(args);

        return fr;
    }

    public DryfruitsMenuItem1FormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new DryfruitsMenuItem1FormFormPresenter(
                (CrudDatasource) getDatasource(),
                this));

        addBehavior(pageViewBehavior("DryfruitsMenuItem1Form"));
    }

    @Override
    protected ProductsDSItem newItem() {
        ProductsDSItem newItem = new ProductsDSItem();
        return newItem;
    }

    private ProductsDSService getRestService(){
        return ProductsDSService.getInstance();
    }

    @Override
    protected int getLayout() {
        return R.layout.dryfruitsmenuitem1form_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ProductsDSItem item, View view) {
        
        bindString(R.id.productsds_name, item.name, false, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.name = s.toString();
            }
        });
        
        
        bindString(R.id.productsds_productavaialble, item.productavaialble, false, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.productavaialble = s.toString();
            }
        });
        
        
        bindString(R.id.productsds_category, item.category, false, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.category = s.toString();
            }
        });
        
        
        bindString(R.id.productsds_priceperunitkglt, item.pricePerunitkglt, false, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.pricePerunitkglt = s.toString();
            }
        });
        
        
        bindString(R.id.productsds_rating, item.rating, false, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.rating = s.toString();
            }
        });
        
        
        bindImage(R.id.productsds_picture,
            item.picture != null ?
                getRestService().getImageUrl(item.picture) : null,
            false,
            0,
            new ImagePicker.Callback(){
                @Override
                public void imageRemoved(){
                    item.picture = null;
                    item.pictureUri = null;
                    ((ImagePicker) getView().findViewById(R.id.productsds_picture)).clear();
                }
            }
        );
        
        
        bindString(R.id.productsds_quantity, item.quantity, false, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.quantity = s.toString();
            }
        });
        
        
        bindString(R.id.productsds_contact, item.contact, false, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.contact = s.toString();
            }
        });
        
    }

    @Override
    public Datasource<ProductsDSItem> getDatasource() {
        if (datasource != null) {
            return datasource;
        }
        datasource = ProductsDS.getInstance(new SearchOptions());
        return datasource;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == Activity.RESULT_OK) {
            ImagePicker picker = null;
            Uri imageUri = null;
            ProductsDSItem item = getItem();

            if((requestCode & ImagePicker.GALLERY_REQUEST_CODE) == ImagePicker.GALLERY_REQUEST_CODE) {
                imageUri = data.getData();
                switch (requestCode - ImagePicker.GALLERY_REQUEST_CODE) {
                        
                        case 0:   // picture field
                            item.pictureUri = imageUri;
                            item.picture = "cid:picture";
                            picker = (ImagePicker) getView().findViewById(R.id.productsds_picture);
                            break;
                        
                    default:
                        return;
                }

                picker.setImageUri(imageUri);
            } else if((requestCode & ImagePicker.CAPTURE_REQUEST_CODE) == ImagePicker.CAPTURE_REQUEST_CODE) {
                switch (requestCode - ImagePicker.CAPTURE_REQUEST_CODE) {
                        
                        case 0:   // picture field
                            picker = (ImagePicker) getView().findViewById(R.id.productsds_picture);
                            imageUri = fromFile(picker.getImageFile());
                        		item.pictureUri = imageUri;
                            item.picture = "cid:picture";
                            break;
                        
                    default:
                        return;
                }
                picker.setImageUri(imageUri);
            }
        }
    }
}
