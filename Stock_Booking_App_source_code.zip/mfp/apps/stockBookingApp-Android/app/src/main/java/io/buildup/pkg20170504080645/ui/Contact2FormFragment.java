
package io.buildup.pkg20170504080645.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import buildup.ui.FormFragment;
import buildup.views.TextWatcherAdapter;
import io.buildup.pkg20170504080645.ds.ContactScreen1DSItem;
import io.buildup.pkg20170504080645.ds.ContactScreen1DSService;
import io.buildup.pkg20170504080645.presenters.Contact2FormFormPresenter;
import io.buildup.pkg20170504080645.R;
import buildup.ds.Datasource;
import buildup.ds.CrudDatasource;
import buildup.ds.SearchOptions;
import buildup.ds.filter.Filter;
import java.util.Arrays;
import io.buildup.pkg20170504080645.ds.ContactScreen1DSItem;
import io.buildup.pkg20170504080645.ds.ContactScreen1DS;
import static buildup.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;

public class Contact2FormFragment extends FormFragment<ContactScreen1DSItem> {

    private CrudDatasource<ContactScreen1DSItem> datasource;
    public static Contact2FormFragment newInstance(Bundle args){
        Contact2FormFragment fr = new Contact2FormFragment();
        fr.setArguments(args);

        return fr;
    }

    public Contact2FormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new Contact2FormFormPresenter(
                (CrudDatasource) getDatasource(),
                this));

        addBehavior(pageViewBehavior("contact2Form"));
    }

    @Override
    protected ContactScreen1DSItem newItem() {
        ContactScreen1DSItem newItem = new ContactScreen1DSItem();
        return newItem;
    }

    private ContactScreen1DSService getRestService(){
        return ContactScreen1DSService.getInstance();
    }

    @Override
    protected int getLayout() {
        return R.layout.contact2form_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ContactScreen1DSItem item, View view) {
        
        bindString(R.id.contactscreen1ds_name, item.name, false, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.name = s.toString();
            }
        });
        
        
        bindString(R.id.contactscreen1ds_addresss, item.addresss, false, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.addresss = s.toString();
            }
        });
        
        
        bindString(R.id.contactscreen1ds_email, item.email, false, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.email = s.toString();
            }
        });
        
    }

    @Override
    public Datasource<ContactScreen1DSItem> getDatasource() {
        if (datasource != null) {
            return datasource;
        }
        datasource = ContactScreen1DS.getInstance(new SearchOptions());
        return datasource;
    }
}
