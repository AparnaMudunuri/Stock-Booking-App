
package io.buildup.pkg20170504080645.ui;

import android.support.v4.app.Fragment;
import android.util.SparseArray;

import buildup.ui.DrawerActivity;

import buildup.actions.StartActivityAction;
import buildup.util.Constants;
import io.buildup.pkg20170504080645.R;

public class StockBookingAppMainActivity extends DrawerActivity {

    private final SparseArray<Class<? extends Fragment>> sectionFragments = new SparseArray<>();
    {
            sectionFragments.append(R.id.entry0, StockDetailsFragment.class);
            sectionFragments.append(R.id.entry1, ContactDetailsFragment.class);
            sectionFragments.append(R.id.entry2, LogoutFragment.class);
    }

    @Override
    public SparseArray<Class<? extends Fragment>> getSectionFragmentClasses() {
      return sectionFragments;
    }

}
