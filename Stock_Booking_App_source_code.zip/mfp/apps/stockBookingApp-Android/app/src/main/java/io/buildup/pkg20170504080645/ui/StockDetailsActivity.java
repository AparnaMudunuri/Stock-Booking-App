

package io.buildup.pkg20170504080645.ui;

import android.os.Bundle;
import android.support.v4.app.Fragment;

import io.buildup.pkg20170504080645.R;

import buildup.ui.BaseListingActivity;
/**
 * StockDetailsActivity list activity
 */
public class StockDetailsActivity extends BaseListingActivity {

    @Override
    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);

        if(isTaskRoot()) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        } else {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        
        setTitle(getString(R.string.stockDetailsActivity));
    }

    @Override
    protected Class<? extends Fragment> getFragmentClass() {
        return StockDetailsFragment.class;
    }

}
