
package io.buildup.pkg20170504080645.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import buildup.behaviors.FabBehaviour;
import buildup.behaviors.ShareBehavior;
import buildup.ds.restds.AppNowDatasource;
import buildup.mvp.presenter.DetailCrudPresenter;
import buildup.util.ColorUtils;
import buildup.util.Constants;
import buildup.util.image.ImageLoader;
import buildup.util.image.PicassoImageLoader;
import buildup.util.StringUtils;
import io.buildup.pkg20170504080645.ds.ProductsDSService;
import io.buildup.pkg20170504080645.presenters.DryfruitsMenuItem1DetailPresenter;
import io.buildup.pkg20170504080645.R;
import java.net.URL;
import static buildup.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import buildup.ds.Datasource;
import buildup.ds.CrudDatasource;
import buildup.dialogs.DeleteItemDialog;
import android.support.v4.app.DialogFragment;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.analytics.AnalyticsReporter;
import static buildup.analytics.model.AnalyticsInfo.Builder.analyticsInfo;
import static buildup.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;
import buildup.ds.SearchOptions;
import buildup.ds.filter.Filter;
import java.util.Arrays;
import io.buildup.pkg20170504080645.ds.ProductsDSItem;
import io.buildup.pkg20170504080645.ds.ProductsDS;

public class DryfruitsMenuItem1DetailFragment extends buildup.ui.DetailFragment<ProductsDSItem> implements ShareBehavior.ShareListener, DeleteItemDialog.DeleteItemListener {

    private CrudDatasource<ProductsDSItem> datasource;
    private AnalyticsReporter analyticsReporter;
    public static DryfruitsMenuItem1DetailFragment newInstance(Bundle args){
        DryfruitsMenuItem1DetailFragment fr = new DryfruitsMenuItem1DetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public DryfruitsMenuItem1DetailFragment(){
        super();
    }

    @Override
    public Datasource<ProductsDSItem> getDatasource() {
        if (datasource != null) {
            return datasource;
        }
        datasource = ProductsDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        addBehavior(pageViewBehavior("DryfruitsMenuItem1Detail"));
        analyticsReporter = AnalyticsReporterInjector.analyticsReporter(getActivity());
        // the presenter for this view
        setPresenter(new DryfruitsMenuItem1DetailPresenter(
                (CrudDatasource) getDatasource(),
                this));
        // Edit button
        addBehavior(new FabBehaviour(this, R.drawable.ic_edit_white, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((DetailCrudPresenter<ProductsDSItem>) getPresenter()).editForm(getItem());
            }
        }));
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.dryfruitsmenuitem1detail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ProductsDSItem item, View view) {
        
        ImageView view0 = (ImageView) view.findViewById(R.id.view0);
        URL view0Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.picture);
        if(view0Media != null){
            ImageLoader imageLoader = new PicassoImageLoader(view0.getContext(), false);
            imageLoader.load(imageLoaderRequest()
                                   .withPath(view0Media.toExternalForm())
                                   .withTargetView(view0)
                                   .fit()
                                   .build()
                    );
            
        } else {
            view0.setImageDrawable(null);
        }
        
        TextView view1 = (TextView) view.findViewById(R.id.view1);
        view1.setText(String.format("Name : %s", item.name));
        
        
        TextView view2 = (TextView) view.findViewById(R.id.view2);
        view2.setText(String.format("Product Available : %s", item.productavaialble));
        
        
        TextView view3 = (TextView) view.findViewById(R.id.view3);
        view3.setText(String.format("Price (/kg) : %s", item.pricePerunitkglt));
        
        
        TextView view4 = (TextView) view.findViewById(R.id.view4);
        view4.setText(String.format("Rating : %s", item.rating));
        
        
        TextView view5 = (TextView) view.findViewById(R.id.view5);
        view5.setText(String.format("Quantity : %s", item.quantity));
        
        
        TextView view6 = (TextView) view.findViewById(R.id.view6);
        view6.setText(String.format("Contact No: %s", item.contact));
        
    }

    @Override
    protected void onShow(ProductsDSItem item) {
        // set the title for this fragment
        getActivity().setTitle(null);
    }

    @Override
    public void navigateToEditForm() {
        Bundle args = new Bundle();

        args.putInt(Constants.ITEMPOS, 0);
        args.putParcelable(Constants.CONTENT, getItem());
        args.putInt(Constants.MODE, Constants.MODE_EDIT);

        Intent intent = new Intent(getActivity(), DryfruitsMenuItem1FormFormActivity.class);
        intent.putExtras(args);
        startActivityForResult(intent, Constants.MODE_EDIT);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.delete_menu, menu);

        MenuItem item = menu.findItem(R.id.action_delete);
        ColorUtils.tintIcon(item, R.color.textBarColor, getActivity());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.action_delete){
            DialogFragment deleteDialog = new DeleteItemDialog(this);
            deleteDialog.show(getActivity().getSupportFragmentManager(), "");
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    
    @Override
    public void deleteItem(boolean isDeleted) {
        if(isDeleted) {
            ((DetailCrudPresenter<ProductsDSItem>) getPresenter()).deleteItem(getItem());
        }
    }
    @Override
    public void onShare() {
        ProductsDSItem item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, String.format("Name : %s", item.name) + "\n" +
                    String.format("Product Available : %s", item.productavaialble) + "\n" +
                    String.format("Price (/kg) : %s", item.pricePerunitkglt) + "\n" +
                    String.format("Rating : %s", item.rating) + "\n" +
                    String.format("Quantity : %s", item.quantity) + "\n" +
                    String.format("Contact No: %s", item.contact));

        analyticsReporter.sendEvent(analyticsInfo()
                            .withAction("share")
                            .withTarget(String.format("Name : %s", item.name) + "\n" +
                    String.format("Product Available : %s", item.productavaialble) + "\n" +
                    String.format("Price (/kg) : %s", item.pricePerunitkglt) + "\n" +
                    String.format("Rating : %s", item.rating) + "\n" +
                    String.format("Quantity : %s", item.quantity) + "\n" +
                    String.format("Contact No: %s", item.contact))
                            .withDataSource("ProductsDS")
                            .build().toMap()
        );
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}
