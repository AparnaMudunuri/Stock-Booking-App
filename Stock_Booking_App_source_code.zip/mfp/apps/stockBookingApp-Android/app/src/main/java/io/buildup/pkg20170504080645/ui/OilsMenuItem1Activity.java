

package io.buildup.pkg20170504080645.ui;

import android.os.Bundle;
import android.support.v4.app.Fragment;

import io.buildup.pkg20170504080645.R;

import buildup.ui.BaseListingActivity;
/**
 * OilsMenuItem1Activity list activity
 */
public class OilsMenuItem1Activity extends BaseListingActivity {

    @Override
    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);

        if(isTaskRoot()) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        } else {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        
        setTitle(getString(R.string.oilsMenuItem1Activity));
    }

    @Override
    protected Class<? extends Fragment> getFragmentClass() {
        return OilsMenuItem1Fragment.class;
    }

}
