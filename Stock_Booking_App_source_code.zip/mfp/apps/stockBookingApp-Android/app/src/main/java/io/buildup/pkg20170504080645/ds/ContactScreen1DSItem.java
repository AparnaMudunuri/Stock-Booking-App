
package io.buildup.pkg20170504080645.ds;

import buildup.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class ContactScreen1DSItem implements Parcelable, IdentifiableBean {

    @SerializedName("name") public String name;
    @SerializedName("addresss") public String addresss;
    @SerializedName("email") public String email;
    @SerializedName("contact") public Long contact;
    @SerializedName("id") public String id;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(addresss);
        dest.writeString(email);
        dest.writeValue(contact);
        dest.writeString(id);
    }

    public static final Creator<ContactScreen1DSItem> CREATOR = new Creator<ContactScreen1DSItem>() {
        @Override
        public ContactScreen1DSItem createFromParcel(Parcel in) {
            ContactScreen1DSItem item = new ContactScreen1DSItem();

            item.name = in.readString();
            item.addresss = in.readString();
            item.email = in.readString();
            item.contact = (Long) in.readValue(null);
            item.id = in.readString();
            return item;
        }

        @Override
        public ContactScreen1DSItem[] newArray(int size) {
            return new ContactScreen1DSItem[size];
        }
    };

}

