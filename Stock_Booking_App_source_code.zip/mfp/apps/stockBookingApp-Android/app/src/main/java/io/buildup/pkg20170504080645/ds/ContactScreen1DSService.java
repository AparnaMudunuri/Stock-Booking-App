
package io.buildup.pkg20170504080645.ds;
import java.net.URL;
import io.buildup.pkg20170504080645.R;
import buildup.ds.RestService;
import buildup.util.StringUtils;

/**
 * "ContactScreen1DSService" REST Service implementation
 */
public class ContactScreen1DSService extends RestService<ContactScreen1DSServiceRest>{

    public static ContactScreen1DSService getInstance(){
          return new ContactScreen1DSService();
    }

    private ContactScreen1DSService() {
        super(ContactScreen1DSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://pods.hivepod.io";
    }

    @Override
    protected String getApiKey() {
        return "fIIbdod6";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://pods.hivepod.io/app/590ae112a8185b0400f3b54c",
                path,
                "apikey=fIIbdod6");
    }

}
