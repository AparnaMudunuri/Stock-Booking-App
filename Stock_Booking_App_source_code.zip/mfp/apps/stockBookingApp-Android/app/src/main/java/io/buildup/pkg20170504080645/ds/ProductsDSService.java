
package io.buildup.pkg20170504080645.ds;
import java.net.URL;
import io.buildup.pkg20170504080645.R;
import buildup.ds.RestService;
import buildup.util.StringUtils;

/**
 * "ProductsDSService" REST Service implementation
 */
public class ProductsDSService extends RestService<ProductsDSServiceRest>{

    public static ProductsDSService getInstance(){
          return new ProductsDSService();
    }

    private ProductsDSService() {
        super(ProductsDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://pods.hivepod.io";
    }

    @Override
    protected String getApiKey() {
        return "fIIbdod6";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://pods.hivepod.io/app/590ae112a8185b0400f3b54c",
                path,
                "apikey=fIIbdod6");
    }

}
