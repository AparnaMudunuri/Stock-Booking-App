
package io.buildup.pkg20170504080645.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import buildup.actions.ActivityIntentLauncher;
import buildup.actions.MailAction;
import buildup.actions.MapsAction;
import buildup.actions.PhoneAction;
import buildup.behaviors.FabBehaviour;
import buildup.behaviors.ShareBehavior;
import buildup.mvp.presenter.DetailCrudPresenter;
import buildup.util.ColorUtils;
import buildup.util.Constants;
import buildup.util.StringUtils;
import io.buildup.pkg20170504080645.ds.ContactScreen1DSService;
import io.buildup.pkg20170504080645.presenters.ContactDetailsDetailPresenter;
import io.buildup.pkg20170504080645.R;
import buildup.ds.Datasource;
import buildup.ds.CrudDatasource;
import buildup.dialogs.DeleteItemDialog;
import android.support.v4.app.DialogFragment;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.analytics.AnalyticsReporter;
import static buildup.analytics.model.AnalyticsInfo.Builder.analyticsInfo;
import static buildup.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;
import buildup.ds.SearchOptions;
import buildup.ds.filter.Filter;
import java.util.Arrays;
import io.buildup.pkg20170504080645.ds.ContactScreen1DSItem;
import io.buildup.pkg20170504080645.ds.ContactScreen1DS;

public class ContactDetailsDetailFragment extends buildup.ui.DetailFragment<ContactScreen1DSItem> implements ShareBehavior.ShareListener, DeleteItemDialog.DeleteItemListener {

    private CrudDatasource<ContactScreen1DSItem> datasource;
    private AnalyticsReporter analyticsReporter;
    public static ContactDetailsDetailFragment newInstance(Bundle args){
        ContactDetailsDetailFragment fr = new ContactDetailsDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public ContactDetailsDetailFragment(){
        super();
    }

    @Override
    public Datasource<ContactScreen1DSItem> getDatasource() {
        if (datasource != null) {
            return datasource;
        }
        datasource = ContactScreen1DS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        addBehavior(pageViewBehavior("contactDetailsDetail"));
        analyticsReporter = AnalyticsReporterInjector.analyticsReporter(getActivity());
        // the presenter for this view
        setPresenter(new ContactDetailsDetailPresenter(
                (CrudDatasource) getDatasource(),
                this));
        // Edit button
        addBehavior(new FabBehaviour(this, R.drawable.ic_edit_white, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((DetailCrudPresenter<ContactScreen1DSItem>) getPresenter()).editForm(getItem());
            }
        }));
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.contactdetailsdetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ContactScreen1DSItem item, View view) {
        
        TextView view0 = (TextView) view.findViewById(R.id.view0);
        view0.setText((item.name != null ? item.name : ""));
        
        
        TextView view1 = (TextView) view.findViewById(R.id.view1);
        view1.setText((item.addresss != null ? item.addresss : ""));
        ColorUtils.tintIcon(view1.getCompoundDrawables()[2], R.color.textColor, getActivity());
        bindAction(view1, new MapsAction(new ActivityIntentLauncher(), (item.addresss != null ? item.addresss : "")));
        
        TextView view2 = (TextView) view.findViewById(R.id.view2);
        view2.setText((item.email != null ? item.email : ""));
        ColorUtils.tintIcon(view2.getCompoundDrawables()[2], R.color.textColor, getActivity());
        bindAction(view2, new MailAction(new ActivityIntentLauncher(), (item.email != null ? item.email : "")));
        
        TextView view3 = (TextView) view.findViewById(R.id.view3);
        view3.setText((item.contact != null ? item.contact.toString() : ""));
        ColorUtils.tintIcon(view3.getCompoundDrawables()[2], R.color.textColor, getActivity());
        bindAction(view3, new PhoneAction(new ActivityIntentLauncher(), (item.contact != null ? item.contact.toString() : "")));
    }

    @Override
    protected void onShow(ContactScreen1DSItem item) {
        // set the title for this fragment
        getActivity().setTitle(null);
    }

    @Override
    public void navigateToEditForm() {
        Bundle args = new Bundle();

        args.putInt(Constants.ITEMPOS, 0);
        args.putParcelable(Constants.CONTENT, getItem());
        args.putInt(Constants.MODE, Constants.MODE_EDIT);

        Intent intent = new Intent(getActivity(), Contact2FormFormActivity.class);
        intent.putExtras(args);
        startActivityForResult(intent, Constants.MODE_EDIT);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.delete_menu, menu);

        MenuItem item = menu.findItem(R.id.action_delete);
        ColorUtils.tintIcon(item, R.color.textBarColor, getActivity());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.action_delete){
            DialogFragment deleteDialog = new DeleteItemDialog(this);
            deleteDialog.show(getActivity().getSupportFragmentManager(), "");
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    
    @Override
    public void deleteItem(boolean isDeleted) {
        if(isDeleted) {
            ((DetailCrudPresenter<ContactScreen1DSItem>) getPresenter()).deleteItem(getItem());
        }
    }
    @Override
    public void onShare() {
        ContactScreen1DSItem item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, (item.name != null ? item.name : "") + "\n" +
                    (item.addresss != null ? item.addresss : "") + "\n" +
                    (item.email != null ? item.email : "") + "\n" +
                    (item.contact != null ? item.contact.toString() : ""));

        analyticsReporter.sendEvent(analyticsInfo()
                            .withAction("share")
                            .withTarget((item.name != null ? item.name : "") + "\n" +
                    (item.addresss != null ? item.addresss : "") + "\n" +
                    (item.email != null ? item.email : "") + "\n" +
                    (item.contact != null ? item.contact.toString() : ""))
                            .withDataSource("ContactScreen1DS")
                            .build().toMap()
        );
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}
