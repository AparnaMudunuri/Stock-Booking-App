package io.buildup.pkg20170504080645.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import buildup.behaviors.AnalyticsSearchBehavior;
import buildup.behaviors.FabBehaviour;
import buildup.behaviors.SelectionBehavior;
import buildup.ds.Datasource;
import buildup.ds.filter.StringFilter;
import buildup.ds.restds.AppNowDatasource;
import buildup.ui.ListGridFragment;
import buildup.util.ColorUtils;
import buildup.util.Constants;
import buildup.util.image.ImageLoader;
import buildup.util.image.PicassoImageLoader;
import buildup.util.StringUtils;
import buildup.util.ViewHolder;
import io.buildup.pkg20170504080645.ds.ProductsDSService;
import io.buildup.pkg20170504080645.presenters.VegetablesfruitsPresenter;
import io.buildup.pkg20170504080645.R;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import static buildup.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import buildup.ds.SearchOptions;
import buildup.ds.filter.Filter;
import java.util.Arrays;
import io.buildup.pkg20170504080645.ds.ProductsDSItem;
import io.buildup.pkg20170504080645.ds.ProductsDS;
import buildup.mvp.view.CrudListView;
import buildup.ds.CrudDatasource;
import buildup.dialogs.DeleteItemDialog;
import android.support.v4.app.DialogFragment;
import android.content.Intent;
import buildup.util.Constants;
import static buildup.util.NavigationUtils.generateIntentToDetailOrForm;
import static buildup.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;

/**
 * "VegetablesfruitsFragment" listing
 */
public class VegetablesfruitsFragment extends ListGridFragment<ProductsDSItem> implements CrudListView<ProductsDSItem>, DeleteItemDialog.DeleteItemListener {

    private CrudDatasource<ProductsDSItem> datasource;
    private List<ProductsDSItem> selectedItemsForDelete;

    
    ArrayList<String> rating_values;
    // "Add" button
    private FabBehaviour fabBehavior;

    public static VegetablesfruitsFragment newInstance(Bundle args) {
        VegetablesfruitsFragment fr = new VegetablesfruitsFragment();

        fr.setArguments(args);
        return fr;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addBehavior(pageViewBehavior("Vegetablesfruits"));
        setPresenter(new VegetablesfruitsPresenter(
            (CrudDatasource) getDatasource(),
            this
        ));
        addBehavior(new AnalyticsSearchBehavior(this, "ProductsDS"));
        // Multiple selection
        SelectionBehavior<ProductsDSItem> selectionBehavior = new SelectionBehavior<>(
            this,
            R.string.remove_items,
            R.drawable.ic_delete_alpha);

        selectionBehavior.setCallback(new SelectionBehavior.Callback<ProductsDSItem>() {
            @Override
            public void onSelected(List<ProductsDSItem> selectedItems) {
                selectedItemsForDelete = selectedItems;
                DialogFragment deleteDialog = new DeleteItemDialog(VegetablesfruitsFragment.this);
                deleteDialog.show(getActivity().getSupportFragmentManager(), "");
            }
        });
        addBehavior(selectionBehavior);

        // FAB button
        fabBehavior = new FabBehaviour(this, R.drawable.ic_add_white, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getPresenter().addForm();
            }
        });
        addBehavior(fabBehavior);
        
    }

    protected SearchOptions getSearchOptions() {
        SearchOptions.Builder searchOptionsBuilder = SearchOptions.Builder.searchOptions();
        searchOptionsBuilder
            .withFixedFilters(Arrays.<Filter>asList(new StringFilter("category", "Vegetables ")));
        return searchOptionsBuilder.build();
    }


    /**
    * Layout for the list itselft
    */
    @Override
    protected int getLayout() {
        return R.layout.fragment_list;
    }

    /**
    * Layout for each element in the list
    */
    @Override
    protected int getItemLayout() {
        return R.layout.vegetablesfruits_item;
    }

    @Override
    protected Datasource<ProductsDSItem> getDatasource() {
        if (datasource != null) {
            return datasource;
        }
        datasource = ProductsDS.getInstance(getSearchOptions());
        return datasource;
    }

    @Override
    protected void bindView(ProductsDSItem item, View view, int position) {
        
        ImageLoader imageLoader = new PicassoImageLoader(view.getContext(), false);
        ImageView image = ViewHolder.get(view, R.id.image);
        URL imageMedia = ((AppNowDatasource) getDatasource()).getImageUrl(item.picture);
        if(imageMedia != null){
            imageLoader.load(imageLoaderRequest()
                          .withPath(imageMedia.toExternalForm())
                          .withTargetView(image)
                          .fit()
        				  .build()
            );
        	
        }
        else {
            imageLoader.load(imageLoaderRequest()
                          .withResourceToLoad(R.drawable.ic_ibm_placeholder)
                          .withTargetView(image)
        				  .build()
            );
        }
        
        
        TextView title = ViewHolder.get(view, R.id.title);
        
        title.setText((item.name != null ? item.name : ""));
        
        
        TextView subtitle = ViewHolder.get(view, R.id.subtitle);
        
        subtitle.setText((item.productavaialble != null ? item.productavaialble : ""));
        
    }

    @Override
    protected void itemClicked(final ProductsDSItem item, final int position) {
        fabBehavior.hide(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                getPresenter().detail(item, position);
            }
        });
    }

    @Override
    public void showDetail(ProductsDSItem item, int position) {
        Intent intent = generateIntentToDetailOrForm(item,
            position,
            getActivity(),
            VegetablesfruitsDetailActivity.class);

        if (!getResources().getBoolean(R.bool.tabletLayout)) {
            startActivityForResult(intent, Constants.DETAIL);
        } else {
            startActivity(intent);
        }
    }

    @Override
    public void showAdd() {
        startActivityForResult(
                generateIntentToDetailOrForm(null,
                        0,
                        getActivity(),
                        VegetablesfruitsFormFormActivity.class
                ), Constants.MODE_CREATE
        );
    }

    @Override
    public void showEdit(ProductsDSItem item, int position) {
        startActivityForResult(
                generateIntentToDetailOrForm(item,
                        position,
                        getActivity(),
                        VegetablesfruitsFormFormActivity.class
                ), Constants.MODE_EDIT
        );
    }
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);

        // inflate menu options and tint icon
        inflater.inflate(R.menu.filter_menu, menu);
        ColorUtils.tintIcon(menu.findItem(R.id.filter),
                            R.color.textBarColor,
                            getActivity());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.filter){
            Intent intent = new Intent(getActivity(), VegetablesfruitsFilterActivity.class);

            // pass current values to filter activity
            Bundle args = new Bundle();
            args.putParcelable("search_options", getSearchOptions());
            
            intent.putStringArrayListExtra("rating_values", rating_values);
			intent.putExtras(args);
            // launch filter screen
            startActivityForResult(intent, 1);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 1 && resultCode == Activity.RESULT_OK){
            // store the incoming selection
                        
            rating_values = data.getStringArrayListExtra("rating_values");
            // apply filter to datasource
            clearFilters();

                        
            if(rating_values != null && rating_values.size() > 0)
                addStringFilter("rating", rating_values);
            // and finally refresh the list
            refresh();

            // and redraw menu (to refresh tinted icons, like the search icon)
            getActivity().invalidateOptionsMenu();
        }
    }

    @Override
    public void deleteItem(boolean isDeleted) {
        if (isDeleted) {
            getPresenter().deleteItems(selectedItemsForDelete);
        }

        selectedItemsForDelete.clear();
    }

}
